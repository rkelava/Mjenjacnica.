﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using Mjenjacnica.Models;

namespace Mjenjacnica.IServices
{
    public class KorisnikRepository : IKorisnikRepository
    {
        private readonly ConnectionString _connectionString;

        public KorisnikRepository (ConnectionString connectionString)
        {
            _connectionString = connectionString;
        }

        public Task<IEnumerable<Korisnik>> GetAllKorisnik()
        {
            const string query = @"SELECT k.id, k.korisnicko_ime, k.lozinka, k.ime, k.prezime, k.email, k.slika, k.tip_korisnika_id 
                                  FROM Korisnik k";

            using (var conn = new SqlConnection(_connectionString.Value))
            {
                var result = conn.QueryAsync<Korisnik>(query); //using dapper
                return result;
            }

            throw new NotImplementedException();
        }
        
        //dohvacanje korisnika putam id-a
        public async Task<Korisnik> GetKorisnikById(int id)
        {
            const string query = @"SELECT k.id, k.korisnicko_ime, k.lozinka, k.ime, k.prezime, k.email, k.slika, k.tip_korisnika_id 
                                  FROM Korisnik k  
                                  WHERE k.id = @Id";

            using (var conn = new SqlConnection(_connectionString.Value))
            {
                var result = await conn.QueryFirstOrDefaultAsync<Korisnik>(query, new { Id = id });
                return result;
            }
        }

        public async Task<int> AddKorisnik(Korisnik korisnik)
        {
            const string query = @"INSERT INTO Korisnik ([id], [korisnicko_ime], [lozinka], [ime], [prezime], [slika], [tip_korinika_id]) 
                                 VALUES(@id, @korisnicko_ime, @lozinka, @ime, @prezime, @email, @slika, @tip_korisnika_id)";

            using (var conn = new SqlConnection(_connectionString.Value))
            {
                var result = await conn.ExecuteAsync(
                    query,
                    new { id = korisnik.id, korisnicko_ime = korisnik.korisnicko_ime, lozinka = korisnik.lozinka,
                          ime=korisnik.ime, prezime=korisnik.prezime, slika=korisnik.slika, tip_korisnika_id=korisnik.tip_korisnika_id});
                return result;
            }
        }
    }
}
