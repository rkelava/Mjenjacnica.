﻿using Mjenjacnica.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mjenjacnica.IServices
{
    public interface IKorisnikRepository
    {
        Task<IEnumerable<Korisnik>> GetAllKorisnik();
        Task<Korisnik> GetKorisnikById(int id); //dohavacanje korisnika preko id-a
        Task<int> AddKorisnik(Korisnik korisnik);
    }
}
