﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading.Tasks;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Mjenjacnica.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WebApplication1.Models;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller

    {
        private readonly IHttpClientFactory _clientFactory;

        public  RatesModel ratesModels { get; set; }
        //-----
        private readonly IConfiguration _config;
        public HomeController(IHttpClientFactory clientFactory, IConfiguration config)
        {
            _clientFactory = clientFactory;
            _config = config;
        }

        public async Task<IActionResult> Index()
        {
            return View(await GetCurrentRateModelsAsync());
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Registracija()
        { 
            return View();
        }

        [HttpPost]
        public async void CreateRegistracija(Korisnik korisnik)
        { 
            using (var connection = new SqlConnection(_config.GetConnectionString("Mjenjacnica")))
            {
                await connection.OpenAsync();
                var sqlStatement = @"INSERT INTO Korisnik 
                                  (korisnicko_ime,lozinka, ime, prezime, email, slika) 
                                   VALUES (@korisnicko_ime,@lozinka, @ime, @prezime,@email, @slika)";
                await connection.ExecuteAsync(sqlStatement, korisnik);
            }
            
            //return View("Profile");
        }
        private async Task<RatesModel> GetCurrentRateModelsAsync()
        {
            var request = new HttpRequestMessage(HttpMethod.Get,
          "https://api.exchangeratesapi.io/latest");
            var client = _clientFactory.CreateClient();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("aplication/json"));

            var response = await client.SendAsync(request);


            if (response.IsSuccessStatusCode)
            {
                var jsonString = await response.Content.ReadAsStringAsync();
                //!package manager console-> Install-Package System.Text.Json -Version 5.0.0
                ratesModels = JsonConvert.DeserializeObject<RatesModel>(jsonString);

            }
            //else sta ako nema 
            return ratesModels;
        }
    }

    public class RatesDeserializer : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return typeof(RatesModel).IsAssignableFrom(objectType);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, Newtonsoft.Json.JsonSerializer serializer)
        {
            IDictionary<string, double> result;

            if (reader.TokenType == JsonToken.StartArray)
            {
                JArray legacyArray = (JArray)JArray.ReadFrom(reader);

                result = legacyArray.ToDictionary(
                    el => el["Key"].ToString(),
                    el => Convert.ToDouble(el["Value"]));
            }
            else
            {
                result =
                    (IDictionary<string, double>)
                        serializer.Deserialize(reader, typeof(RatesModel));
            }

            return result;
        }

        public override void WriteJson(JsonWriter writer, object value, Newtonsoft.Json.JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }
    }
}
