﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Mjenjacnica.IServices;
using Mjenjacnica.Models;

namespace Mjenjacnica.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class KorisnikController : ControllerBase
    {
        private readonly IKorisnikRepository _korisnikRepository;

        public KorisnikController(IKorisnikRepository korisnikRepository)
        {
            _korisnikRepository = korisnikRepository;
        }

        [HttpGet("api/korisnik")]
        public async Task<IActionResult> GetKorisnik()
        {
            return Ok(await _korisnikRepository.GetAllKorisnik());
        }

        [HttpGet("api/korisnik/{id}")]
        public async Task<IActionResult> GetKorisnik(int id)
        {
            var korisnik = await _korisnikRepository.GetKorisnikById(id);

            if (korisnik != null)
            {
                return Ok(korisnik);
            }
            else
            {
                return NotFound(new { Message = $"Korisnik id => {id} nije dostupan" +
                    $"." });
            }
        }

        [HttpPost("api/registracija")]
        public async Task<IActionResult> AddKorisnik(Korisnik model)
        {
            var result = await _korisnikRepository.AddKorisnik(model);
            if (result > 0)
            {
                return Ok(new { Message = "bravo." });
            }
            else
            {
                return StatusCode(500, new { Message = "greška" });
            }
        }
    }
}