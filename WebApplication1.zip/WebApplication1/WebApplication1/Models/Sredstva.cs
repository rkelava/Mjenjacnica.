﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mjenjacnica.Models
{
    public class Sredstva
    {
        public int sredstva_id { get; set; }
        public decimal iznos { get; set; }
        public int valuta_id { get; set; }
        public int korisnik_id { get; set; }
    }
}
