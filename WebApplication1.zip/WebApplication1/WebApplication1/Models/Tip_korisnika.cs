﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mjenjacnica.Models
{
    public class Tip_korisnika
    {
        public int tip_korisnika_id { get; set; }
        public string naziv { get; set; }
    }
}
