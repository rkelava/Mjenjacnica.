﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mjenjacnica.Models
{
    public class Valuta
    {
        public int valuta_id { get; set; }
        public string naziv_valute { get; set; }
        public decimal tecaj { get; set; }
        public string slika { get; set; }
        public string zvuk { get; set; }
        public DateTime aktivno_od { get; set; }
        public DateTime aktivno_do { get; set; }
        public DateTime datum_azuriranja { get; set; }
        public int moderator_id { get; set; }
    }
}
