﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mjenjacnica.Models
{
    public class Zahtjev
    {
        public int zahtjev_id { get; set; }
        public decimal iznos { get; set; }
        public DateTime datum_vrijeme_kreiranja{ get; set; }
        public Boolean prihvacen { get; set; }
        public int korisnik_id { get; set; }
        public int prodajem_valuta_id { get; set; }
        public int kupujem_valuta_id { get; set; }
    }
}
