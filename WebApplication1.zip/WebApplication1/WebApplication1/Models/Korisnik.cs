﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mjenjacnica.Models
{
    public class Korisnik
    {
        public int id { get; set; }
        public string korisnicko_ime { get; set; }
        public string lozinka { get; set; }
        public string ime { get; set; }
        public string prezime { get; set; }
        public string email { get; set; }
        public string slika { get; set; }
        public int tip_korisnika_id { get; set; }
    }
}
